# Join-Remove

-👋🏻 Salom Men bilan Aloqa: +998935338025

-🐍 Portfolio uchun

-👥 Guruhlarda kirdi chiqdini tozalash uchun 
