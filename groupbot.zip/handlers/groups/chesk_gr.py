from aiogram import types
from aiogram.types import ContentTypes
from keyboards.inline.inline import guruh
from filters.guruh import Guruh
from loader import dp, bot

gr_id = '-1001831195516'

@dp.message_handler(Guruh())
async def gr_join(message: types.Message):
    chesk_group = await bot.get_chat_member(chat_id=gr_id,user_id=message.from_user.id)
    if chesk_group['status']!= 'left':
        pass
    else:
        await message.delete()
        await message.answer(text="botdan foidalanish uchun 2chi guruhimizga obuna boling",reply_markup=types.InlineKeyboardMarkup().add(types.InlineKeyboardButton(text=f"gr", url=f'https://t.me/wlebievefb')))

@dp.callback_query_handler(Guruh())
async def gr_join(call: types.CallbackQuery):
    if call.data=='subdone':
        chesk_group = await bot.get_chat_member(chat_id=gr_id,user_id=call.message.from_user.id)
        if chesk_group['status'] != 'left':
            pass
        else:
            await call.message.delete()
            # for g in gr_id:
            #     gr = await bot.get_chat(g)
            await call.message.answer(text="botdan foidalanish uchun 2chi guruhimizga obuna boling",
                                     reply_markup=types.InlineKeyboardMarkup().add(
                                         types.InlineKeyboardButton(text=f"gr", url=f'https://t.me/wlebievefb')))